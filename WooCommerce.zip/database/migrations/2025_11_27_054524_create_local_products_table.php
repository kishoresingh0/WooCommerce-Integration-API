<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up()
    {
        Schema::create('local_products', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('woocommerce_id')->unique();
            $table->string('name');
            $table->string('sku')->unique();
            $table->decimal('price', 10, 2);
            $table->text('description')->nullable();
            $table->text('short_description')->nullable();
            $table->integer('quantity')->default(0);
            $table->string('weight')->nullable();
            $table->json('categories')->nullable();
            $table->json('raw_data')->nullable(); // Store complete WooCommerce data
            $table->timestamp('last_synced_at');
            $table->timestamps();

            $table->index('sku');
            $table->index('woocommerce_id');
        });
    }

    public function down()
    {
        Schema::dropIfExists('local_products');
    }
};
