<?php

return [
    'store_url' => env('WOOCOMMERCE_STORE_URL'),
    'consumer_key' => env('WOOCOMMERCE_CONSUMER_KEY'),
    'consumer_secret' => env('WOOCOMMERCE_CONSUMER_SECRET'),
    'options' => [
        'version' => env('WC_VERSION'),
        'timeout' => 60,
        'verify_ssl' => false, // Disable for testing
        'query_string_auth' => true, // Force query string auth
        'wp_api' => true,
    ],
];
