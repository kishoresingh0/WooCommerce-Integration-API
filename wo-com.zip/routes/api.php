<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ProductController;

Route::get('/test', function () {
    return response()->json([
        'message' => 'Laravel WooCommerce API is working!',
        'timestamp' => now(),
        'version' => '1.0'
    ]);
});

// WooCommerce API routes
Route::prefix('woocommerce')->group(function () {
    // Test connection
    Route::get('/test-connection', [ProductController::class, 'testConnection']);

    // Product CRUD operations
    Route::post('/products', [ProductController::class, 'create']);
    Route::put('/products/{id}', [ProductController::class, 'update']);
    Route::get('/products', [ProductController::class, 'index']);
    Route::delete('/products/{id}', [ProductController::class, 'destroy']);

    //Synchronize all products locally
    Route::post('/sync', [ProductController::class, 'sync']);


});
