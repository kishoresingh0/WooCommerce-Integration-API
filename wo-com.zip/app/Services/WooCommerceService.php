<?php

namespace App\Services;

use Automattic\WooCommerce\Client;
use Illuminate\Support\Facades\Log;
use Exception;

class WooCommerceService
{
    protected $client;

    public function __construct()
    {
        $storeUrl = config('woocommerce.store_url');
        $consumerKey = config('woocommerce.consumer_key');
        $consumerSecret = config('woocommerce.consumer_secret');

        // Validate credentials
        if (empty($storeUrl) || empty($consumerKey) || empty($consumerSecret)) {
            throw new Exception('WooCommerce credentials are not configured in .env file');
        }

        Log::info('Initializing WooCommerce client', [
            'store_url' => $storeUrl,
            'consumer_key' => substr($consumerKey, 0, 10) . '...'
        ]);

        $this->client = new Client(
            $storeUrl,
            $consumerKey,
            $consumerSecret,
            config('woocommerce.options')
        );
    }

    public function createProduct($data)
    {

        try {
            Log::info('Creating product in WooCommerce', ['data' => $data]);
            $response = $this->client->post('products', $data);
            Log::info('Product created successfully', ['product_id' => $response->id]);
            return $response;
        } catch (Exception $e) {
            Log::error('Failed to create product', ['error' => $e->getMessage(), 'data' => $data]);
            throw new Exception('Failed to create product: ' . $e->getMessage());
        }
    }

    public function updateProduct($id, $data)
    {
        try {
            Log::info('Updating product in WooCommerce', ['product_id' => $id, 'data' => $data]);
            $response = $this->client->put("products/{$id}", $data);
            Log::info('Product updated successfully', ['product_id' => $id]);
            return $response;
        } catch (Exception $e) {
            Log::error('Failed to update product', ['product_id' => $id, 'error' => $e->getMessage()]);
            throw new Exception('Failed to update product: ' . $e->getMessage());
        }
    }

    public function getProducts($params = [])
    {
        try {
            Log::info('Fetching products from WooCommerce', ['params' => $params]);
            $response = $this->client->get('products', $params);
            Log::info('Products fetched successfully', ['count' => count($response)]);
            return $response;
        } catch (Exception $e) {
            Log::error('Failed to fetch products', ['error' => $e->getMessage()]);
            throw new Exception('Failed to fetch products: ' . $e->getMessage());
        }
    }

    /**
     * Get products by SKU
     */
    public function getProductsBySku($sku)
    {
        try {
            Log::info('Searching products by SKU', ['sku' => $sku]);

            $products = $this->client->get('products', [
                'sku' => $sku,
                'per_page' => 1
            ]);

            Log::info('SKU search results', [
                'sku' => $sku,
                'found' => count($products)
            ]);

            return $products;

        } catch (Exception $e) {
            Log::error('Failed to search products by SKU', [
                'sku' => $sku,
                'error' => $e->getMessage()
            ]);
            throw $e;
        }
    }

    /**
     * Check if SKU exists in WooCommerce
     */
    public function checkSkuExists($sku): bool
    {
        try {
            $products = $this->getProductsBySku($sku);
            return count($products) > 0;
        } catch (Exception $e) {
            Log::warning('SKU check failed', ['sku' => $sku, 'error' => $e->getMessage()]);
            return false; // Return false if check fails
        }
    }

    /**
     * Get product by SKU (returns single product or null)
     */
    public function getProductBySku($sku)
    {
        try {
            $products = $this->getProductsBySku($sku);
            return count($products) > 0 ? $products[0] : null;
        } catch (Exception $e) {
            Log::error('Failed to get product by SKU', ['sku' => $sku, 'error' => $e->getMessage()]);
            return null;
        }
    }

    public function deleteProduct($id)
    {
        try {
            Log::info('Deleting product from WooCommerce', ['product_id' => $id]);
            $response = $this->client->delete("products/{$id}", ['force' => true]);
            Log::info('Product deleted successfully', ['product_id' => $id]);
            return $response;
        } catch (Exception $e) {
            Log::error('Failed to delete product', ['product_id' => $id, 'error' => $e->getMessage()]);
            throw new Exception('Failed to delete product: ' . $e->getMessage());
        }
    }

    // Test connection method
    public function testConnection()
    {
        try {
            Log::info('Testing WooCommerce API connection');
            $response = $this->client->get('products', ['per_page' => 1]);
            Log::info('Connection test successful', ['products_count' => count($response)]);
            return [
                'success' => true,
                'message' => 'Connection successful',
                'products_count' => count($response)
            ];
        } catch (Exception $e) {
            Log::error('Failed to connect to WooCommerce', ['error' => $e->getMessage()]);
            return [
                'success' => false,
                'message' => 'Failed to connect to WooCommerce'
            ];
        }
    }


    public function syncAllProducts($params = [])
    {
        try {
            Log::info('Starting full product sync from WooCommerce');

            $defaultParams = ['per_page' => 100, 'page' => 1];
            $params = array_merge($defaultParams, $params);

            $allProducts = [];
            $page = 1;

            do {
                $params['page'] = $page;
                Log::info('Fetching products page', ['page' => $page]);

                $products = $this->client->get('products', $params);

                if (empty($products)) {
                    break;
                }

                $allProducts = array_merge($allProducts, $products);
                $page++;

                // Safety limit to prevent infinite loops
                if ($page > 50) {
                    Log::warning('Reached sync page limit');
                    break;
                }

            } while (count($products) === $params['per_page']);

            Log::info('Product sync completed', [
                'total_products' => count($allProducts),
                'pages_processed' => $page - 1
            ]);

            return $allProducts;

        } catch (Exception $e) {
            Log::error('Failed to sync products', ['error' => $e->getMessage()]);
            throw new Exception('Product sync failed: ' . $e->getMessage());
        }
    }
}
