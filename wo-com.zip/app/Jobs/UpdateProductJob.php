<?php

namespace App\Jobs;

use App\Services\WooCommerceService;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Log;

class UpdateProductJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public $tries = 3;
    public $timeout = 60;

    public function __construct(
        protected int $productId,
        protected array $productData
    ) {
    }

    public function handle(WooCommerceService $woocommerceService): void
    {
        Log::info('🔄 Processing product update job', [
            'product_id' => $this->productId,
            'attempt' => $this->attempts()
        ]);

        try {
            $response = $woocommerceService->updateProduct($this->productId, $this->productData);

            Log::info('✅ Product updated successfully via job', [
                'product_id' => $this->productId,
                'product_name' => $response->name,
                'sku' => $response->sku
            ]);

        } catch (\Exception $e) {
            Log::error('❌ Failed to update product via job', [
                'error' => $e->getMessage(),
                'product_id' => $this->productId,
                'attempt' => $this->attempts()
            ]);

            throw $e;
        }
    }

    public function failed(\Exception $e): void
    {
        Log::error('💥 Product update job failed after all attempts', [
            'error' => $e->getMessage(),
            'product_id' => $this->productId
        ]);
    }
}
