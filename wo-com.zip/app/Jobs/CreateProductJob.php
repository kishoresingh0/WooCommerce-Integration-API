<?php

namespace App\Jobs;

use App\Services\WooCommerceService;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Log;

class CreateProductJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public $tries = 3; // Number of retry attempts
    public $timeout = 60; // Timeout in seconds
    public $backoff = [10, 30, 60]; // Backoff delays between retries

    public function __construct(protected array $productData)
    {
    }

    public function handle(WooCommerceService $woocommerceService): void
    {
        Log::info('🔄 Processing product creation job', [
            'sku' => $this->productData['sku'],
            'name' => $this->productData['name'],
            'attempt' => $this->attempts()
        ]);

        try {
            $response = $woocommerceService->createProduct($this->productData);

            Log::info('✅ Product created successfully via job', [
                'product_id' => $response->id,
                'product_name' => $response->name,
                'sku' => $response->sku
            ]);

        } catch (\Exception $e) {
            Log::error('❌ Failed to create product via job', [
                'error' => $e->getMessage(),
                'sku' => $this->productData['sku'],
                'attempt' => $this->attempts(),
                'data' => $this->productData
            ]);

            // Re-throw the exception to trigger retry
            throw $e;
        }
    }

    /**
     * Handle a job failure
     */
    public function failed(\Exception $e): void
    {
        Log::error('💥 Product creation job failed after all attempts', [
            'error' => $e->getMessage(),
            'sku' => $this->productData['sku'],
            'name' => $this->productData['name']
        ]);

        // You can also send notification, update database, etc.
        // Mail::to('admin@example.com')->send(new ProductCreationFailed($this->productData, $e));
    }
}
