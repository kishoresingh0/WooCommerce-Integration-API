<?php
// app/Models/LocalProduct.php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class LocalProduct extends Model
{
    use HasFactory;

    protected $fillable = [
        'woocommerce_id',
        'name',
        'sku',
        'price',
        'description',
        'short_description',
        'quantity',
        'weight',
        'categories',
        'raw_data',
        'last_synced_at'
    ];

    protected $casts = [
        'categories' => 'array',
        'raw_data' => 'array',
        'last_synced_at' => 'datetime'
    ];
}
