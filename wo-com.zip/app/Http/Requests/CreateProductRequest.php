<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class CreateProductRequest extends FormRequest
{
    public function rules()
    {
        return [
            'name' => 'required|string|max:255',
            'sku' => 'required|string|max:100',
            'price' => 'required|numeric|min:0',
            'description' => 'required|string',
            'short_description' => 'required|string|max:500',
            'quantity' => 'required|integer|min:0',
            'weight' => 'required|string',
            'woocommerce_category_id' => 'required|array',
            'woocommerce_category_id.*' => 'integer',
        ];
    }

    public function messages()
    {
        return [
            'name.required' => 'Product name is required',
            'sku.required' => 'SKU is required',
            'price.required' => 'Price is required',
            'description.required' => 'Description is required',
            'short_description.required' => 'Short description is required',
            'quantity.required' => 'Quantity is required',
            'weight.required' => 'Weight is required',
            'woocommerce_category_id.required' => 'At least one category ID is required',
        ];
    }
}
