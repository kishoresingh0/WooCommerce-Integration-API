<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class UpdateProductRequest extends FormRequest
{
    public function rules()
    {
        return [
            'name' => 'sometimes|string|max:255',
            'sku' => 'sometimes|string|max:100',
            'price' => 'sometimes|numeric|min:0',
            'description' => 'sometimes|string',
            'short_description' => 'sometimes|string|max:500',
            'quantity' => 'sometimes|integer|min:0',
            'weight' => 'sometimes|string',
            'woocommerce_category_id' => 'sometimes|array',
            'woocommerce_category_id.*' => 'integer',
        ];
    }
}
