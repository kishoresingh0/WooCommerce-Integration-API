<?php

namespace App\Http\Controllers;

use App\Http\Requests\CreateProductRequest;
use App\Http\Requests\UpdateProductRequest;
use App\Services\WooCommerceService;
use Illuminate\Support\Facades\Log;
use App\Models\LocalProduct;
use App\Jobs\CreateProductJob;
use App\Jobs\UpdateProductJob;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Exception;

class ProductController extends Controller
{
    protected $woocommerceService;

    public function __construct(WooCommerceService $woocommerceService)
    {
        $this->woocommerceService = $woocommerceService;
    }

    /**
     * Test API connection
     */
    public function testConnection(): JsonResponse
    {
        try {
            $result = $this->woocommerceService->testConnection();

            return response()->json([
                'status' => $result['success'] ? 'success' : 'error',
                'message' => $result['message'],
                'data' => $result
            ], $result['success'] ? 200 : 500);

        } catch (Exception $e) {
            return response()->json([
                'status' => 'error',
                'message' => 'Connection test failed: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Create a new product
     */
    public function create(CreateProductRequest $request): JsonResponse
    {

    $existingProducts = $this->woocommerceService->getProductsBySku($request->sku);

    if (count($existingProducts) > 0) {

        $existingProduct = $existingProducts[0];

        return response()->json([
            'status' => 'error',
            'message' => "SKU '{$request->sku}' already exists for product: '{$existingProduct->name}' (ID: {$existingProduct->id})",
            // 'existing_product' => [
            //     'id' => $existingProduct->id,
            //     'name' => $existingProduct->name,
            //     'sku' => $existingProduct->sku,
            //     'price' => $existingProduct->price
            // ]
        ], 422);
    }

        try {
            $productData = [
                'name' => $request->name,
                'sku' => $request->sku,
                'regular_price' => (string) $request->price,
                'description' => $request->description,
                'short_description' => $request->short_description,
                'manage_stock' => true,
                'stock_quantity' => $request->quantity,
                'weight' => $request->weight,
                'categories' => array_map(function($categoryId) {
                    return ['id' => $categoryId];
                }, $request->woocommerce_category_id),
                'status' => 'publish'
            ];
            //ONLY direct call (no job)
            //$response = $this->woocommerceService->createProduct($productData);

            // Dispatch the job to the queue
            CreateProductJob::dispatch($productData);
            Log::info('Product creation job dispatched', [
                'product_id' => $request->id,
                'sku' => $request->sku,
                'name' => $request->name
            ]);

            return response()->json([
                'status' => 'success',
                'message' => 'Product created successfully'
            ], 201);

        } catch (Exception $e) {
            return response()->json([
                'status' => 'error',
                'message' => 'Failed to create product: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Update an existing product
     */
    public function update(UpdateProductRequest $request, $id): JsonResponse
    {
        try {
            $productData = [];

            // Map fields to WooCommerce format
            if ($request->has('name')) $productData['name'] = $request->name;
            if ($request->has('sku')) $productData['sku'] = $request->sku;
            if ($request->has('price')) $productData['regular_price'] = (string) $request->price;
            if ($request->has('description')) $productData['description'] = $request->description;
            if ($request->has('short_description')) $productData['short_description'] = $request->short_description;
            if ($request->has('quantity')) {
                $productData['manage_stock'] = true;
                $productData['stock_quantity'] = $request->quantity;
            }
            if ($request->has('weight')) $productData['weight'] = $request->weight;
            if ($request->has('woocommerce_category_id')) {
                $productData['categories'] = array_map(function($categoryId) {
                    return ['id' => $categoryId];
                }, $request->woocommerce_category_id);
            }

            // ONLY direct call (no job)
            //$this->woocommerceService->updateProduct($id, $productData);

            // Dispatch update job
            UpdateProductJob::dispatch($id, $productData);
            Log::info('Product update job dispatched', ['product_id' => $id]);

            return response()->json([
                'status' => 'success',
                'message' => 'Product updated successfully on WooCommerce'
            ]);

        } catch (Exception $e) {
            return response()->json([
                'status' => 'error',
                'message' => 'Failed to update product: ' . $e->getMessage()
            ], 500);
        }
    }

    /**
     * Fetch all products
     */
    public function index(Request $request): JsonResponse
    {
        try {
            $params = [];

            // Add pagination and search
            if ($request->has('page')) $params['page'] = $request->page;
            if ($request->has('per_page')) $params['per_page'] = $request->per_page;
            if ($request->has('search')) $params['search'] = $request->search;

            $products = $this->woocommerceService->getProducts($params);

            return response()->json([
                'status' => 'success',
                'fetched' => count($products),
                'products' => $products
            ]);

        } catch (Exception $e) {
            return response()->json([
                'status' => 'error',
                'message' => 'Failed to fetch products: ' . $e->getMessage()
            ], 500);
        }
    }



    /**
     * Delete a product
     */
    public function destroy($id): JsonResponse
    {
        try {
            $this->woocommerceService->deleteProduct($id);

            return response()->json([
                'success' => true,
                'message' => 'Product permanently deleted from WooCommerce.'
            ]);

        } catch (Exception $e) {
            return response()->json([
                'status' => 'error',
                'message' => 'Failed to delete product: ' . $e->getMessage()
            ], 500);
        }
    }


    public function sync(Request $request): JsonResponse
    {
        try {
            $params = [];

            if ($request->has('per_page')) $params['per_page'] = $request->per_page;
            if ($request->has('status')) $params['status'] = $request->status;

            $products = $this->woocommerceService->syncAllProducts($params);

            $syncedCount = 0;
            $updatedCount = 0;
            $skippedCount = 0;
            $errors = [];

            foreach ($products as $product) {
                try {
                    // Generate unique SKU for empty values
                    $sku = $product->sku ?? '';
                    if (empty($sku) || $sku === '') {
                        $sku = 'WC_' . $product->id . '_' . uniqid();
                    }

                    // Ensure SKU is truly unique
                    $originalSku = $sku;
                    $counter = 1;
                    while (LocalProduct::where('sku', $sku)->where('woocommerce_id', '!=', $product->id)->exists()) {
                        $sku = $originalSku . '_' . $counter;
                        $counter++;
                    }

                    $productData = [
                        'woocommerce_id' => $product->id,
                        'name' => $product->name ?? 'Unnamed Product',
                        'sku' => $sku,
                        'price' => $product->price ?? 0,
                        'description' => $product->description ?? '',
                        'short_description' => $product->short_description ?? '',
                        'quantity' => $product->stock_quantity ?? 0,
                        'weight' => $product->weight ?? '',
                        'categories' => $product->categories ?? [],
                        'raw_data' => $product,
                        'last_synced_at' => now(),
                    ];

                    // Use updateOrCreate to handle both new and existing products
                    $localProduct = LocalProduct::updateOrCreate(
                        ['woocommerce_id' => $product->id],
                        $productData
                    );

                    if ($localProduct->wasRecentlyCreated) {
                        $syncedCount++;
                    } else {
                        $updatedCount++;
                    }

                } catch (\Exception $e) {
                    $skippedCount++;
                    $errors[] = "Product ID {$product->id}: " . $e->getMessage();
                    Log::error('Failed to sync product', [
                        'product_id' => $product->id,
                        'sku' => $product->sku ?? 'empty',
                        'error' => $e->getMessage()
                    ]);
                }
            }

            $response = [
                'status' => 'success',
                'message' => 'Products synchronization completed',
                'data' => [
                    'total_fetched' => count($products),
                    'newly_synced' => $syncedCount,
                    'updated' => $updatedCount,
                    'skipped' => $skippedCount,
                    'total_local' => LocalProduct::count()
                ]
            ];

            if ($skippedCount > 0) {
                $response['warnings'] = array_slice($errors, 0, 10); // Show first 10 errors only
            }

            return response()->json($response);

        } catch (Exception $e) {
            return response()->json([
                'status' => 'error',
                'message' => 'Sync failed: ' . $e->getMessage()
            ], 500);
        }
    }
}
